function [err] = errorestimate(xc, xf, uhc, uhf, EToVc, EToVf, Old2New)
    
end